
public class Affichage {

    //classe de test pour afficher les différents menus et le déroulé du programme


    //L'utilisateur informe de son statut prop ou loc
    /*public static void choixStatut(Scanner sc) {
        String choix = "";
        System.out.println("Veuillez choisir un statut : ");
        System.out.println("1 - Propriétaire");
        System.out.println("2 - Locataire");
        System.out.println("3 - Quitter");
        choix = sc.nextLine();
        if (choix.equals("1")){
            affichageProprietaire(sc); 
        }
        else if (choix.equals("2")){
            affichageLocataire(sc);
        }
        else if (choix.equals("3")){
            System.out.println("Au revoir");
        }
    }*/





    /*public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        choixStatut(sc);
        sc.close();
    }*/
}