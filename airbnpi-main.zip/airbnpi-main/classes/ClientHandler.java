import java.io.*;
import java.net.Socket;
import java.util.Scanner;

class ClientHandler implements Runnable {

	    private Socket socket;
		private BufferedReader br;
		private PrintWriter pw;
		private Proprietaire proprietaire;
		private Locataire locataire;
		private String nom;
		private Boolean estLocataire;

		ClientHandler(Socket socket,Boolean estLocataire) {
			try{
			this.socket=socket;
			this.pw = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
			this.br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			this.estLocataire=estLocataire;
			} catch(IOException e) {}
		}

		public void affichageProprietaire(Scanner sc, Proprietaire proprietaire) {
			int choix;
			pw.write("Que voulez-vous faire ? \n 1 - Voir l'historique des loyers payés \n 2 - Envoyer un rappel \n 3 - Quitter");
			pw.flush();
			choix = Integer.parseInt(sc.nextLine());

			switch (choix) {
				case 1:
					proprietaire.voirHistoriqueLoyer();
					break;
		
				case 2:
					proprietaire.envoyerRappel(pw);
					break;
				case 3:
					pw.write("Au revoir");
					pw.flush();
					break;
		
				default:
					pw.write("Choix invalide");
					pw.flush();
			}
		}
		

		public void affichageLocataire(Scanner sc, Locataire locataire) {
			int choix;
			pw.write("Que voulez-vous faire ? \n 1 - Payer le loyer \n 2 - Voir l'historique des loyers payés \n 3 - Gérer les tâches \n 4 - Quitter");
			pw.flush();
			choix = Integer.parseInt(sc.nextLine());

			switch (choix) {
				case 1:
					locataire.payerLoyer();
					break;
		
				case 2:
					locataire.voirHistoriqueLoyer();
					break;
		
				case 3:
					locataire.gererTaches();
					break;
		
				case 4:
					pw.write("Au revoir");
					pw.flush();
					break;
		
				default:
					pw.write("Choix invalide");
					pw.flush();
			}
		}
		
			
	    public void run() {
			Scanner sc=new Scanner(br);
			this.nom=Identification.identification(estLocataire,sc);
			if(estLocataire)
			{
				this.locataire=new Locataire(nom, null);
			}
			else
			{
				this.proprietaire=new Proprietaire(nom, null);
			}

			while(true)
			{
				if(estLocataire)
				{
					affichageLocataire(sc,locataire);
				}
				else
				{
					affichageProprietaire(sc,proprietaire);
				}
			}
	    }

				/*BufferedReader in;
				String pseudo;
	            try {
	                while(true){

	                	socket = serveur.getSocketserver().accept(); // Un client se connecte on l'accepte
						nbrclient++;
	                    System.out.println("Le client numéro "+nbrclient+ " est connecté !");
						//in = new BufferedReader (new InputStreamReader (socket.getInputStream()));
						//pseudo = in.readLine();
						//this.serveur.getSockets().put(pseudo,socket);
						//new Thread(new TransmettreMessageServeur(in, serveur,pseudo)).start();
					
	                }           
	            } catch (IOException e) {
	            	
	                e.printStackTrace();
	            }
	        }*/
}