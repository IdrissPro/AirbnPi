import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.io.*;

public class Proprietaire implements gestionPaiement{

    //On définit le nom et l'unique appartement du propriétaire
    private String nom;
    private Appartement appartement;
    private PrintWriter pw;
    private BufferedReader br;

    public Proprietaire(String nom, Appartement appartement){
        this.nom = nom;
        this.appartement = appartement;
    }

    public String getNom(){
        return this.nom;
    }

    public Appartement getAppartement(){
        return this.appartement;
    }

    public void voirHistoriqueLoyer(Socket socket){
        //on parcours la liste des locataires, si ceux ci sont dans 'appartement' alors on affiche leur nom et si ils ont payé le loyer
        try{
            for (Locataire locataire : appartement.getListeLocataires()) {
                pw = new PrintWriter(socket.getOutputStream(), true);
                pw.println("Locataire : " + locataire.getNom() + " Loyer payé : " + locataire.getLoyerPaye());
            }
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void sauvegarderMessage(String message,String nomDestinataire)
    {
        try{
        //Les fichiers locataires devront avoir la syntaxe Nom_role.txt (role=Locataire ou Proprietaire)
        PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(nomDestinataire + "_locataire.txt", true))); //true pour ouvrir le fichier en mode ajout
        // Ajouter le nouveau message au fichier du locataire
        writer.println(message); 
        writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void envoyerRappel(PrintWriter pw){
        //on parcours la liste des locataires, on affiche leur nom et si ils ont payé le loyer
        for (Locataire locataire : appartement.getListeLocataires()) {
            if (locataire.getLoyerPaye()==false) {
                pw.println("Veuillez payer votre/vos loyer(s) en retard");
                //Sauvegarder ce message dans le fichier locataire correspondant
                sauvegarderMessage("Veuillez payer votre/vos loyer(s) en retard",locataire.getNom());
            }

        }
    }
}