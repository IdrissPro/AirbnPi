import java.io.*;
import java.net.Socket;
import java.util.Scanner;

class ClientHandler implements Runnable {

	    private Socket socket;
		private BufferedReader br;
		private PrintWriter pw;
		private Proprietaire proprietaire;
		private Locataire locataire;
		private String nom;
		private int clientId;
		private Boolean estLocataire;
		private static int count = 0;  // On le met en static pour que le compteur est partagée dans toutes les instances de classe

		ClientHandler(Socket socket,Boolean estLocataire) {
			try{
			
			this.socket=socket;
			this.pw = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
			this.br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			this.estLocataire=estLocataire;
			this.clientId = count++;
			} catch(IOException e) {}
		}

	

    public int getClientId() {
        return clientId;
    }
		public void affichageProprietaire(Proprietaire proprietaire) {
			try{
				String choix;
				pw.println("Que voulez-vous faire ? \n 1 - Voir l'historique des loyers payés \n 2 - Envoyer un rappel \n 3 - Quitter");
				pw.println("");
				choix = br.readLine();
				switch (choix) {
					case "1":
						proprietaire.voirHistoriqueLoyer(socket);
						break;
			
					case "2":
						proprietaire.envoyerRappel(pw);
						break;
					case "3":
						pw.println("Au revoir");
						break;
			
					default:
						pw.println("Choix invalide");
				}
			} catch(IOException e) {}
		}
		

		public void affichageLocataire(Locataire locataire) {
			
			try{
				String choix;
				pw.println("Que voulez-vous faire ? \n 1 - Payer le loyer \n 2 - Voir l'historique des loyers payés \n 3 - Gérer les tâches \n 4 - Quitter");
				pw.println("");
				choix = br.readLine();
				switch (choix) {
				case "1":
					locataire.payerLoyer();
					break;
		
				case "2":
					locataire.voirHistoriqueLoyer(socket);
					break;
		
				case "3":
					locataire.gererTaches(socket);
					break;
		
				case "4":
					pw.println("Au revoir");
					break;
		
				default:
					pw.println("Choix invalide");
			}
			} catch(IOException e) {}
		}
		
			
	    public void run() {
			pw.println("Votre numéro de client est : "+clientId+"");
			Scanner sc=new Scanner(br);
			this.nom=Identification.identification(estLocataire,socket);
			if(estLocataire)
			{
				this.locataire=new Locataire(nom, null);
			}
			else
			{
				this.proprietaire=new Proprietaire(nom, null);
			}
			while(true)
			{
				if(estLocataire)
				{
					affichageLocataire(locataire);
				}
				else
				{
					affichageProprietaire(proprietaire);
				}
			}
	    }

				/*BufferedReader in;
				String pseudo;
	            try {
	                while(true){

	                	socket = serveur.getSocketserver().accept(); // Un client se connecte on l'accepte
						nbrclient++;
	                    System.out.println("Le client numéro "+nbrclient+ " est connecté !");
						//in = new BufferedReader (new InputStreamReader (socket.getInputStream()));
						//pseudo = in.readLine();
						//this.serveur.getSockets().put(pseudo,socket);
						//new Thread(new TransmettreMessageServeur(in, serveur,pseudo)).start();
					
	                }           
	            } catch (IOException e) {
	            	
	                e.printStackTrace();
	            }
	        }*/
}