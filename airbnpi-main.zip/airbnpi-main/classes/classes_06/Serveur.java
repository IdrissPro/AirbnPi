import java.io.IOException;
import java.net.Socket;
import java.net.ServerSocket;

public class Serveur {

    public static void main(String[] args) {
        ServerSocket serverSocket = null;

        try {
            //Création d'un locataire dans la liste des locataires
            Identification.ajouterLocataire("L", "mdp");
            Identification.ajouterProprietaire("P", "mdp");
            serverSocket = new ServerSocket(2009);
            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("Un client s'est connecté");
                ClientHandler clientHandler = new ClientHandler(socket, false);
                // Créer un Thread et démarrer le thread
                Thread thread = new Thread(clientHandler);
                thread.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            // Fermer le ServerSocket dans le bloc finally
            if (serverSocket != null && !serverSocket.isClosed()) {
                try {
                    serverSocket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}


