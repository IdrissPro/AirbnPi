import java.io.*;
import java.util.Scanner;
import java.net.*;


public class Client {

    public static boolean role;
    public static Scanner scan = new Scanner(System.in);

    public static boolean definirRole(Scanner scan){
        boolean role;
        System.out.println("Qui est tu? 1)Locataire 2)Propriétaire");
        int choix = scan.nextInt();
        while(choix!=1 && choix!=2)
        {
            System.out.println("Choix invalide. Veuillez choisir une option valide.");
            choix=scan.nextInt();
        }
        role=(choix==1);
        return(role);
    }

    public static void main(String[] zero) {
        try (Socket socket = new Socket("localhost", 2009);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true)) {
            String message = "";
            while (!message.equals("fin")) {
                String message_distant = " ";
                while(!message_distant.equals("")){
                    message_distant = in.readLine();  //Message_distant est le message que le serveur va envoyer et que le client va reçevoir
                    System.out.println(message_distant); 
                }
                message = scan.nextLine(); //Message est le message que le client va envoyer au serveur
                out.println(message);
            }
        } catch (IOException e) {
            System.err.println("Impossible de créer les flux");
            e.printStackTrace();
        }
    }
    
}