import java.io.*;
import java.net.Socket;
import java.util.ArrayList;


public class Locataire implements gestionPaiement{
    //On définit un nom, un appartement et un booléen pour savoir si le loyer a été payé
    private String nom;
    private Appartement appartement;
    private Boolean loyerPaye;
    private BufferedReader br;
    private PrintWriter pw;
    private ArrayList<Boolean> LoyerPayes;

    //le loyer est initialisé a false, on pourra aussi créer différents locataires avec des loyers a jour ou non
    public Locataire(String nom, Appartement appartement){
        this.nom = nom;
        this.appartement = appartement;
        this.loyerPaye = false;
    }

    public String getNom(){
        return this.nom;
    }

    public Appartement getAppartement(){
        return this.appartement;
    }

    public Boolean getLoyerPaye(){
        return this.loyerPaye;
    }

    public void setNom(String nom){
        this.nom = nom;
    }

    public void setLoyerPaye(Boolean loyerPaye){
        this.loyerPaye = loyerPaye;
    }

    public void setAppartement(Appartement appartement){
        this.appartement = appartement;
    }

    public String toString(){
        return "Locataire : " + this.nom + " Appartement : " + this.appartement.getAdresse() + " Loyer payé : " + this.loyerPaye;
    }

    public void payerLoyer(){
        setLoyerPaye(true);
    }

    //pour le moment l'historique informe juste du statut du loyer en cours
    public void voirHistoriqueLoyer(Socket socket){
        try{
        br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        pw = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
        pw.println("Loyer payé : " + this.loyerPaye);
        } catch(IOException e) {}
    }

    
    //Pas encore implémenter, cette méthode doit : 
    // - afficher les tâches
    // - permettre de les modifier
    // - mettre a jour la liste des tâches

    public void gererTaches(Socket socket){
        try{
        br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        pw = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
        pw.println("Que voulez-vous faire ? \n 1 - Voir les tâches \n 2 - Modifier les tâches \n 3 - Quitter");
        } catch(IOException e) {}
    }
    
}