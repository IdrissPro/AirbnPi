import java.io.*;
import java.util.Scanner;
import java.net.*;


public class Client {
    public static boolean role;
    public static Scanner scan = new Scanner(System.in);

    public static boolean definirRole(Scanner scan)
    {
        boolean role;
        System.out.println("Qui est tu? 1)Locataire 2)Propriétaire");
        int choix = scan.nextInt();
        while(choix!=1 || choix!=2)
        {
            System.out.println("Choix invalide. Veuillez choisir une option valide.");
            choix=scan.nextInt();
        }
        role=(choix==1);
        return(role);
    }

    public static void main(String[] zero){

        try {
            Socket socket= new Socket("localhost",2009);
            role=definirRole(scan);
        	socket.close();
        } catch (IOException e) {         
            e.printStackTrace();
        }
    }
}