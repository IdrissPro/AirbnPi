
public class GestionBar {

    public void distance(Lieu l1,Lieu l2)
    //on vérifie si l2 est un voisin de l1 et on renvoie la distance entre les deux lieux qui est la valeur du dictionnaire
    {
        if (l1.getListeVoisins().containsKey(l2.getAdresse())) {
            System.out.println("La distance entre " + l1.getAdresse() + " et " + l2.getAdresse() + " est de " + l1.obtenirValeur(l2.getAdresse()) + " mètres.");
        } else {
            System.out.println("Les deux lieux ne sont pas voisins.");
        }
    }

    public static void main(String[] args) {
        Lieu l1 = new Lieu("1 rue de la paix");
        Lieu l2 = new Lieu("2 rue de la paix");
        Lieu l3 = new Lieu("3 rue de la paix");
        Lieu l4 = new Lieu("4 rue de la paix");
        Lieu l5 = new Lieu("5 rue de la paix");
        //on ajoute les voisins de l1
        l1.ajouterVoisins(l2.getAdresse(), 100);
        l1.ajouterVoisins(l3.getAdresse(), 200);
        l1.ajouterVoisins(l4.getAdresse(), 300);
        //on ajoute les voisins de l2
        l2.ajouterVoisins(l1.getAdresse(), 100);
        l2.ajouterVoisins(l3.getAdresse(), 100);
        //on test la distance entre certains lieux 
        GestionBar gestionBar = new GestionBar();
        gestionBar.distance(l1, l2);
        gestionBar.distance(l1, l3);
        gestionBar.distance(l1, l4);
        gestionBar.distance(l2, l3);
        gestionBar.distance(l2, l4);
        gestionBar.distance(l3, l4);
        gestionBar.distance(l1, l5);

}
}
