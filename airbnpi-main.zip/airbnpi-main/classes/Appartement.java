import java.util.ArrayList;

public class Appartement extends Lieu {

    //Un appartement est un lieu avec une liste de tâches et une liste de locataires
    private ArrayList<String> taches;
    private ArrayList<Locataire> locataires;

    public Appartement(String adresse, ArrayList<String> taches, ArrayList<Locataire> locataires) {
        super(adresse);
        this.taches = new ArrayList<>();
        this.locataires = new ArrayList<>();
    }

    public void setListeLocataires(ArrayList<Locataire> locataires) {
        this.locataires = locataires;
    }

    public ArrayList<Locataire> getListeLocataires() {
        return locataires;
    }

    public Appartement(String adresse) {
        super(adresse);
    }

    public void setTaches(ArrayList<String> taches) {
        this.taches = taches;
    }


    public ArrayList<String> getTaches() {
        return taches;
    }

    public void ajouterTache(String tache) {
        taches.add(tache);
    }

    public void supprimerTache(String tache) {
        taches.remove(tache);
    }
} 

//Ici pas de méthode AddLocataire, car on par du principe que tous les locataires et les propriétaires sont données initialement au programme, et on ne peut pas en rajouter. 