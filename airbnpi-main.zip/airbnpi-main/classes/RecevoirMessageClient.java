/*import java.io.BufferedReader;
import java.io.IOException;

public class RecevoirMessageClient implements Runnable{
    public BufferedReader in;

    public RecevoirMessageClient(BufferedReader in) {
        this.in = in;
    }

    @Override
    public void run() {
        String message_distant;
        try {        
            message_distant = in.readLine();
            while (true) {
                System.out.println(message_distant);
                message_distant = in.readLine();
        }
        } catch (IOException e) {

        }
    }

    public BufferedReader getIn() {
        return in;
    }

    public void setIn(BufferedReader in) {
        this.in = in;
    }
}*/