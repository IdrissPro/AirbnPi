import java.io.*;
import java.net.Socket;
import java.util.Scanner;
import java.util.ArrayList;

class ClientHandler implements Runnable {

	    private Socket socket;
		private BufferedReader br;
		private PrintWriter pw;
		private Proprietaire proprietaire;
		private Locataire locataire;
		private String nom;
		private int clientId;
		private Boolean estLocataire;
		private Appartement appartement;
		private static int count = 1;  // On le met en static pour que le compteur soit partagé dans toutes les instances de classe

		ClientHandler(Socket socket,Boolean estLocataire) {
			try{
			this.socket=socket;
			this.pw = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
			this.br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			this.estLocataire=estLocataire;
			this.clientId = count++;
			} catch(IOException e) {}
		}

		public boolean definirRole(){
			
			try { 
				boolean role;
				String choix;
				pw.println("Qui est tu? 1)Locataire 2)Propriétaire");
				pw.println("");
				choix=br.readLine();
				while(!(choix.equals("1")) && !(choix.equals("2")))
				{
					pw.println("Choix invalide. Veuillez choisir une option valide.");
					choix=br.readLine();
				}
				role=(choix.equals("1"));
				return(role);
			} catch(IOException e) {}
			return false;
		}
	

		public int getClientId() {
			return clientId;
		}

		public void affichageProprietaire(Proprietaire proprietaire) {
			try{
				String choix;
				pw.println("Que voulez-vous faire ? \n 1 - Voir l'historique des loyers payés \n 2 - Envoyer un rappel \n 3 - Quitter");
				pw.println("");
				choix = br.readLine();
				switch (choix) {
					case "1":
						proprietaire.voirHistoriqueLoyer(socket);
						break;
			
					case "2":
						proprietaire.envoyerRappel(pw);
						break;
					case "3":
						pw.println("Au revoir");
						break;
			
					default:
						pw.println("Choix invalide");
				}
			} catch(IOException e) {}
		}
		

		public void affichageLocataire(Locataire locataire) {
			
			try{
				String choix;
				pw.println("Que voulez-vous faire ? \n 1 - Payer le loyer \n 2 - Voir l'historique des loyers payés \n 3 - Gérer les tâches \n 4 - Quitter");
				pw.println("");
				choix = br.readLine();
				switch (choix) {
				case "1":
					locataire.payerLoyer();
					break;
		
				case "2":
					locataire.voirHistoriqueLoyer(socket);
					break;
		
				case "3":
					locataire.gererTaches(socket);
					break;
				case "4":
					//ArrayList<Lieu> listeBars = new ArrayList<>();
					//listeBars = GestionBar.selectionBars(socket, listeBarsExistants);
					break;
		
				default:
					pw.println("Choix invalide");
			}
			} catch(IOException e) {}
		}
		
			
	    public void run() {
			pw.println("Votre numéro de client est : "+clientId+"");
			//Scanner sc=new Scanner(br);
			this.estLocataire=definirRole();
			this.nom=Identification.identification(estLocataire,socket);
			if(estLocataire)
			{
				this.locataire=new Locataire(nom, null); 
				this.appartement=AppartementPartage.getAppartementPartage();
				AppartementPartage.setAppartementPartage(appartement);
				this.locataire.setAppartement(appartement);
				this.appartement.addLocataire(locataire);
			}
			else
			{
				this.proprietaire=new Proprietaire(nom, null);
				this.appartement=AppartementPartage.getAppartementPartage();
				AppartementPartage.setAppartementPartage(appartement);
				this.proprietaire.setAppartement(appartement);
			}
			while(true)
			{
				if(estLocataire)
				{
					affichageLocataire(locataire);
				}
				else
				{
					affichageProprietaire(proprietaire);
				}
			}
	    }

				/*BufferedReader in;
				String pseudo;
	            try {
	                while(true){

	                	socket = serveur.getSocketserver().accept(); // Un client se connecte on l'accepte
						nbrclient++;
	                    System.out.println("Le client numéro "+nbrclient+ " est connecté !");
						//in = new BufferedReader (new InputStreamReader (socket.getInputStream()));
						//pseudo = in.readLine();
						//this.serveur.getSockets().put(pseudo,socket);
						//new Thread(new TransmettreMessageServeur(in, serveur,pseudo)).start();
					
	                }           
	            } catch (IOException e) {
	            	
	                e.printStackTrace();
	            }
	        }*/
}