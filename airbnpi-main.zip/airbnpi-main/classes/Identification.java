
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Identification {

    //création des listes de locataires et de propriétaires avec leur mot de passe
    private static Map<String, String> listeLoc;
    private static Map<String, String> listeProp;

    //création des listes de locataires et de propriétaires
    static {
        listeLoc = new HashMap<>();
        listeProp = new HashMap<>();
    }

    //ajout d'un locataire ou d'un propriétaire
    public static void ajouterLocataire(String nom, String mdp) {
        listeLoc.put(nom, mdp);
    }

    public static void ajouterProprietaire(String nom, String mdp) {
        listeProp.put(nom, mdp);
    }

    //identification d'un locataire ou d'un propriétaire
    public static String identification(Boolean estLocataire,Scanner sc){
        Boolean Acces=false;
        String mdp="";
        String nom;
        System.out.println("Veuillez entrer votre nom");
        nom=sc.nextLine();
        //on vérifie que le nom est bien dans la liste des locataires ou des propriétaires
        while (! (listeLoc.containsKey(nom) || listeProp.containsKey(nom)) ) {

            System.out.println("Nom inconnu, veuillez rentrez un autre nom");
            nom=sc.nextLine();
        }

        if (estLocataire) {
            while (Acces==false){
                System.out.println("Veuillez entrer votre mot de passe :");
                mdp = sc.nextLine();
                if (listeLoc.get(nom).equals(mdp)) {
                    System.out.println("Connexion réussie");
                    Acces=true;
                    
                } else {
                    System.out.println("Mot de passe incorrect");    
                }
            } 
        }   
        else {
            while (Acces==false){
                    System.out.println("Veuillez entrer votre mot de passe :");
                    mdp = sc.nextLine();
                    if (listeProp.get(nom).equals(mdp)) {
                        System.out.println("Connexion réussie");
                        Acces=true;
                    } else {
                        System.out.println("Mot de passe incorrect");
                        
                    }
                } 
            }
        return(nom);
        }
    }

