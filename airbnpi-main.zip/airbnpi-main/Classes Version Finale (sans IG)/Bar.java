public class Bar extends Lieu {//Un bar est juste un lieu, on l'appelle bar pour faire la distinction avec les autres lieux (Appartement)
    
    public Bar(String adresse) {
        super(adresse);  
    }

}
