public class Bar extends Lieu {
    
    //Pour le moment cette classe définit juste une différence entre un bar et un lieu quelconque
    public Bar(String adresse) {
        super(adresse);  
    }

}
