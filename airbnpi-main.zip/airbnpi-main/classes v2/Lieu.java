import java.util.HashMap;
public class Lieu {

    //Lieu générique avec une adresse et une liste de voisins(leur distance est donnée en valeur dans le map)
    private String adresse;
    private HashMap<String, Integer> listeVoisins;

    public Lieu(String adresse) {
        this.adresse = adresse;
        this.listeVoisins = new HashMap<>();
    }

    // Méthodes pour manipuler le dictionnaire 
    public void ajouterVoisins(String voisin, int distance) {
        listeVoisins.put(voisin, distance);
    }

    public int obtenirValeur(String cle) {
        return listeVoisins.get(cle);
    }

    public HashMap<String, Integer> getListeVoisins() {
        return listeVoisins;
    }


    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }
}
