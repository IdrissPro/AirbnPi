import java.util.ArrayList;

public class Appartement extends Lieu {

    //Un appartement est un lieu avec une liste de tâches et une liste de locataires
    private ArrayList<Tâche> taches;
    private ArrayList<Locataire> locataires;

    public Appartement(String adresse, ArrayList<Tâche> taches, ArrayList<Locataire> locataires) {
        super(adresse);
        this.taches = new ArrayList<>();
        this.locataires = new ArrayList<>();
    }

    public void addLocataire(Locataire locataire) {
        locataires.add(locataire);
    }

    public void setListeLocataires(ArrayList<Locataire> locataires) {
        this.locataires = locataires;
    }

    public ArrayList<Locataire> getListeLocataires() {
        return locataires;
    }

    public Appartement(String adresse) {
        super(adresse);
    }

    public void setTaches(ArrayList<Tâche> taches) {
        this.taches = taches;
    }


    public ArrayList<Tâche> getTaches() {
        return taches;
    }

    public Tâche getTache(String nom) {
        for (Tâche tache : taches) {
            if (tache.getNom().equals(nom)) {
                return tache;
            }
        }
        return null;
    }

    public void ajouterTache(Tâche tache) {
        taches.add(tache);
    }

    public void supprimerTache(Tâche tache) {
        taches.remove(tache);
    }
} 

//Ici pas de méthode AddLocataire, car on par du principe que tous les locataires et les propriétaires sont données initialement au programme, et on ne peut pas en rajouter. 