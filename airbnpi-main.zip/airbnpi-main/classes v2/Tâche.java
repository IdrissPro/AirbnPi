public class Tâche {
    
    //Une tâche est un objet avec un statut, un nom et une attribution
    private int statut;
    private String nom;
    private String attribution;

    //On déclare une Tâche avec son nom, en la laissant non attribuée
    public Tâche(String nom) {
        this.nom = nom;
        this.statut = 0;
        this.attribution = "";
    }


    public int getStatut() {
        return statut;
    }

    public String getNom() {
        return nom;
    }

    public String getAttribution() {
        return attribution;
    }

    public String toString() {
        return "Tâche : "+"statut= "+statut+", nom= " + nom +", attribution= " + attribution +" \n";
    }

    public String abandonner(String attribution) {
        if (this.statut == 1) {
            this.statut = 0;
            this.attribution = "";    
            return "La tâche est abandonnée";
        }
        else {
            return"La tâche n'est pas en cours";
        }
    }

    public String terminer() {
        if (this.statut == 1) {
            this.statut = 0;
            this.attribution = "";
            return "La tâche : "+this.nom+" est terminée";
        }
        else {
            return "La tâche "+this.nom+" n'est pas en cours";
        }
    }

    public String commencer(String attribution) {
        if (this.statut == 0) {
            this.statut = 1;
            this.attribution = attribution;
            return "La tâche "+this.nom+" vous à été attribuée";
        }
        else {
            return "La tâche "+this.nom+" n'est pas disponible";
        }
    }

    /*public void disponible() {
        if (this.statut == 2) {
            this.statut = 0;
            this.attribution = "";
        }
        else {
            System.out.println("La tâche n'est pas terminée");
        }
    }*/   
}
