import java.io.*;
import java.util.Scanner;
import java.net.*;


public class Client {

    public static Scanner scan = new Scanner(System.in);

    

    public static void main(String[] zero) {
        try (Socket socket = new Socket("localhost", 2009);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true)) {
            String message = "";
            while (!message.equals("fin")) {
                String message_distant = " ";
                while(!message_distant.equals("")){
                    message_distant = in.readLine();  //Message_distant est le message que le serveur va envoyer et que le client va reçevoir
                    System.out.println(message_distant); 
                }
                message = scan.nextLine(); //Message est le message que le client va envoyer au serveur
                out.println(message);
            }
        } catch (IOException e) {
            System.err.println("Impossible de créer les flux");
            e.printStackTrace();
        }
    }
    
}