import java.util.ArrayList;

public class AppartementPartage {
    
    private static Appartement appartementPartage;

    public static synchronized Appartement getAppartementPartage() {
        if (appartementPartage == null) {
            appartementPartage = new Appartement("adresse", null, new ArrayList<Locataire>());
            // Initialisation des autres propriétés de l'appartement
            ArrayList<Tâche> taches = new ArrayList<Tâche>();
			taches.add(new Tâche("tache1"));
			taches.add(new Tâche("tache2"));
			AppartementPartage.appartementPartage.setTaches(taches);
        }
        return appartementPartage;
    }

    public static synchronized void setAppartementPartage(Appartement appartementPartage) {
        AppartementPartage.appartementPartage = appartementPartage;
    }
}