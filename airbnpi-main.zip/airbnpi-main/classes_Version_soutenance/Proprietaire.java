import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.io.*;

public class Proprietaire implements gestionPaiement{

    //On définit le nom et l'unique appartement du propriétaire
    private String nom;
    private Appartement appartement;
    private PrintWriter pw;
    private BufferedReader br;

    public Proprietaire(String nom, Appartement appartement){
        this.nom = nom;
        this.appartement = appartement;
    }

    public String getNom(){
        return this.nom;
    }

    public Appartement getAppartement(){
        return this.appartement;
    }

    public void setAppartement(Appartement appartement){
        this.appartement = appartement;
    }

    public void voirHistoriqueLoyer(Socket socket){
        //on parcours la liste des locataires, si ceux ci sont dans 'appartement' alors on affiche leur nom et si ils ont payé le loyer
        try{
            pw = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
            for (Locataire locataire : appartement.getListeLocataires()) {
                pw.println("Locataire : " + locataire.getNom() + " Loyer payé : " + locataire.getLoyerPaye() + "\n ");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void sauvegarderMessage(String message,String nomDestinataire)
    {
        try{
        //Les fichiers locataires devront avoir la syntaxe Nom_role.txt (role=Locataire ou Proprietaire)
        PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(nomDestinataire + "_locataire.txt", true))); //true pour ouvrir le fichier en mode ajout
        // Ajouter le nouveau message au fichier du locataire
        writer.println(message); 
        writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void envoyerRappel(Socket socket) {
        try {
            pw = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
            br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter locPw;
            boolean locataireValide = false;
            while (!locataireValide) {
                pw.println("A qui souhaitez-vous envoyer un rappel ?");
                pw.println("");
                String locVisé = br.readLine();
                for (Locataire locataire : appartement.getListeLocataires()) {
                    if (locataire.getNom().equals(locVisé)) {
                        locPw = locataire.getPr();
                        if (locPw != null) {
                            if (locataire.getLoyerPaye()==false){
                                locPw.println("Vous avez du retard dans votre paiement");
                            } else {
                                pw.println("Le locataire a payé son loyer");
                            }
                            locataireValide = true;
                            break;  // Sortir de la boucle for une fois que le locataire est trouvé
                        }
                    }
                }
    
                if (!locataireValide) {
                    pw.println("Le locataire n'est pas connecté... !");
                    break;
                }
            }
        } catch (Exception e) {
            // Gérer les exceptions correctement
            e.printStackTrace();
        }
    }
    
}
