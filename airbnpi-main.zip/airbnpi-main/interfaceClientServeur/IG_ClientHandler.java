import java.io.*;
import java.net.Socket;

class IG_ClientHandler implements Runnable {

	    private Socket socket;
		private BufferedReader br;
		private PrintWriter pw;
		private Proprietaire proprietaire;
		private Locataire locataire;
		private String nom;
		private int clientId;
		private Boolean estLocataire;
		private Appartement appartement;
		private static int count = 1;  // On le met en static pour que le compteur soit partagé dans toutes les instances de classe

		IG_ClientHandler(Socket socket,Boolean estLocataire) {
			try{
			this.socket=socket;
			this.pw = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
			this.br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			this.estLocataire=estLocataire;
			this.clientId = count++;
			} catch(IOException e) {}
		}

		public void gererMessageClient()
		{
			try
			{
				String messageClient=br.readLine();
				String[] listeInstruction = messageClient.split("//");
				switch (listeInstruction[0])
				{
				case "Identification":
					// Message d'identification
					String[] listeIdentifiant = listeInstruction[1].split("/");
					if ( (listeIdentifiant.length==3) && Identification.ig_identification( ("C" == listeIdentifiant[0]) , listeIdentifiant[1], listeIdentifiant[2]) )
					{
						pw.println("covalide"); // FAUX POUR L'INSTANT A MODIFIER SVPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP
					}
					else {pw.println("erreur");}
					break;

				case "PayerLoyer": 
					locataire.payerLoyer(socket);
					pw.println("Loyer payé avec succès");
					break;



					// Message de 

				}

			} catch(IOException e) {System.err.println("Impossible de créer les flux");
			e.printStackTrace();}
		}
		
			
		public void run() {
			pw.println("Votre numéro de client est : "+clientId+"");
			while(true)
			{
				gererMessageClient();
			}
		}
}