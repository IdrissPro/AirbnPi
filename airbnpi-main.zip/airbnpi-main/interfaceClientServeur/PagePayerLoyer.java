import javax.swing.JButton;
import javax.swing.JPanel;

public class PagePayerLoyer extends JPanel
{
    public PagePayerLoyer(GestionnaireAffichage gestionAff,String message)
    {
        JButton bouton1 = new JButton(message);
        bouton1.addActionListener(new BoutonChangementPage(gestionAff, "PageMenuLoyer")); // Changer l'action
        this.add(bouton1);
    }   
}
