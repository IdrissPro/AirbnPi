import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.*;


public class BoutonPayerLoyer implements ActionListener 
{
    private GestionnaireAffichage gestionAff;
    private PrintWriter out;
    private BufferedReader in;
    private static final String PAYERLOYER      = "PagePayerLoyer";

    public BoutonPayerLoyer(GestionnaireAffichage gestionAff) 
    {
        this.gestionAff = gestionAff;
    }

    public void actionPerformed(ActionEvent e) 
    {
        String reponse = "";
        try
        {
            Socket socket = gestionAff.getSocket();
            out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out.println("PayerLoyer//");
            reponse = in.readLine();

        }catch (IOException a) {System.err.println("Impossible de créer les flux");a.printStackTrace();}   

        gestionAff.getPanneauPrincipal().add(new PagePayerLoyer(gestionAff, reponse), PAYERLOYER);
        gestionAff.deplacement("PageLoyer");
    }
}
