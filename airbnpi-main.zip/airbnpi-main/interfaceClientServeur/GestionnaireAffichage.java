import javax.swing.JPanel;
import java.awt.*;
import java.net.*;

public class GestionnaireAffichage {

    private CardLayout cardLayout;
    private JPanel panneauPrincipal;
    private String clePremierePage;
    private Socket socket;

    

    public GestionnaireAffichage(CardLayout cardLayout,  JPanel panneauPrincipal , Socket socket )
    {
        this.cardLayout =cardLayout;
        this.panneauPrincipal = panneauPrincipal;
        this.clePremierePage = "PageAccueil";
        this.socket = socket;
    }

    public CardLayout getJeuxDeCarte(){return this.cardLayout;}
    public JPanel getPanneauPrincipal(){return this.panneauPrincipal;}
    public String getClePremierePage(){return this.clePremierePage;}
    public Socket getSocket(){return this.socket;}

    public void setJeuxDeCarte(CardLayout cardLayout){this.cardLayout = cardLayout;}
    public void setPanneauPrincipal(JPanel panneauPrincipal){this.panneauPrincipal = panneauPrincipal;}
    public void setClePremierePage( String clePremierePage ){this.clePremierePage = clePremierePage;}
    public void setSocket(Socket socket){this.socket=socket;}

    public void deplacement(String Cle){
        this.setClePremierePage(Cle);
        this.getJeuxDeCarte().show(this.getPanneauPrincipal(), Cle);
    }
}
